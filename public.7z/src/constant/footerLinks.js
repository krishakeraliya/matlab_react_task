export const FOOTER_LINKS = {
  navigation: [
    { label: "ראשי", href: "#" },
    { label: "איך זה עובד?", href: "#" },
    { label: "הכלים שלנו", href: "#" },
    { label: "לקוחות משתפים", href: "#" },
    { label: "שאלות תשובות", href: "#" },
  ],

  privacy: [
    { label: "תקנון שימוש", href: "#" },
    { label: "מדיניות פרטיות", href: "#" },
    { label: "עוגיות", href: "#" },
  ],

  contact: {
    email: "shushanran@gmail.com",
  },
};
