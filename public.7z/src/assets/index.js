import cardPic from './cardPic.png';
import Logo from './logo.png';
import ProfilePic from "./ProfilePic.png"
import Logo1 from "./Logos/ProfileSection.png"
import Logo2 from "./Logos/img1.png"
import Logo3 from "./Logos/img2.png"
import Logo4 from "./Logos/img3.png"
import Logo5 from "./Logos/img4.png"
import Logo6 from "./Logos/img5.png"
import Logo7 from "./Logos/img6.png"

export {
    cardPic,
    Logo,
    ProfilePic,
    Logo1,
    Logo2,
    Logo3,
    Logo4,
    Logo5,
    Logo6,
    Logo7
}